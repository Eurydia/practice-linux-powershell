#!bin/bash

position=$1

echo $(($position * 2))